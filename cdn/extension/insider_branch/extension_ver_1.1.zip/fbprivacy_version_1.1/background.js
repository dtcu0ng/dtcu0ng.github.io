//Re-developed by CuongZ
//NULL